

        Blowfish Eggdrop 1.6.3 PasswordsPro modules v1.1b
        +++++++++++++++++++++++++++++++++++++++++++++++++


Software required
    * PasswordsPro - http://www.insidepro.com/


   Introduction
   ++++++++++++

   Eggdrop IRC bot uses blowfish to encrypt passwords.
   The plaintext is { 0xdeadd061,0x23f6b095 }

   
   Module details
   ++++++++++++++
   
   Its written in assembly, using blowfish implementation by WiteG
   No optimizations are used right now..will be added later.


   Kevin Devine <wyse101@gmail.com>


   February 5th  - v1.1b
      * update to reflect API changes

   November 20th - v1.1
      * some changes made to blowfish code to make it compatible with Eggdrop sources

   November 16th - v1.0
      * first version