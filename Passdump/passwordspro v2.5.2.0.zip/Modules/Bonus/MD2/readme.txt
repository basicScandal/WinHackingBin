

        RSA MD2 PasswordsPro modules v1.0b
        ++++++++++++++++++++++++++++++++++


Software required
    * PasswordsPro - http://www.insidepro.com/


   Introduction
   ++++++++++++

   Read http://tools.ietf.org/html/rfc1319 for more information

   
   Module details
   ++++++++++++++
   
   Its written in assembly, but not optimized.


   Kevin Devine <wyse101@gmail.com>

   February 5th - v1.1b
      * update to reflect API changes

   November 21st - v1.0
      * first release