
Kevin Devine <wyse101@gmail.com>

February 5th 2008
   * update to reflect API changes

November 15th 2007
   * minor optimizations, slight improvement.

November 14th 2007
   * pre-release v1.0b