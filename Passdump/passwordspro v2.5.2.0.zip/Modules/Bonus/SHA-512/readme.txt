

        SHA-2 512 (sse2) PasswordsPro modules v1.2b
        +++++++++++++++++++++++++++++++++++++++++++


Software required
    * PasswordsPro - http://www.insidepro.com/

    February 5th - v1.2b
      * update to reflect API changes

    November 25th - v1.1
      * fixed some silly bugs which caused PP to crash.

    November 22nd - v1.0
      * first release