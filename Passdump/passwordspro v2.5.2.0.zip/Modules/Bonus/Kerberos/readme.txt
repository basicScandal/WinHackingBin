
   Kevin Devine <wyse101 @ gmail.com>



                                Kerberos V5 TSM modules for PasswordsPro
                                ****************************************

   Introduction:
   +++++++++++++
       These modules are for recovery of NT user passwords which encrypt Kerberos v5 Authentication Requests.
       These AS-REQ packets are sent by Windows o/s clients, part of a domain. - See RFC 4757 for details.

       In the AS-REQ packet is an encrypted timestamp, if you're using KerberosV5TSM.dll, you need to know
       the year/day and month packet was sent/captured, see KerberosV5TSM.txt for example format.

       If you don't know the date packet was sent, use KerberosV5TSM(2).dll which is a little slower, examples
       are of course given in KerberosV5TSM(2).txt



   Usage:
        * PasswordsPro is required: http://www.insidepro.com/

        * Ensure in General Options that [Convert passwords to Unicode before hashing] is ticked
        * There IS a limit of 16 byte passwords processed.


   Date of timestamp is known
   ++++++++++++++++++++++++++
       In KerberosV5TSM.txt are dummy entries that PasswordsPro will load (no tool i know currently exists to dump
       these messages from the network in format PPro will accept, so manual extraction with wireshark/ethereal..etc is done :/ )

       I would write one but haven't access to domain..feel free to send some pcap examples.

       The following pcap example and snapshot, kerb1_sniff.jpg, was supplied by dragonii on forum.insidepro.com.

       bob:3230303831313230:02E837D06B2AC76891F388D9CC36C67A2A9785BF5036C45D3843490BF9C228E8C18653E10CE58D7F8EF119D2EF4F92B1803B1451::

       username:YYYYMMDD:PA_ENC_TIMESTAMP::

       You'll need to know what YYYYMMDD is..
       Example given for user "bob" is 20th November, 2008 - the string "20081120" in hex "3230303831313230"

       The PA_ENC_TIMESTAMP is part of the AS-REQ packet.
       First 16 bytes are the checksum of plaintext, remaining bytes are encrypted plaintext.


   Date of timestamp is unknown
   ++++++++++++++++++++++++++++
       In KerberosV5TSM(2).txt are examples of encrypted timestamps where you dont know the plaintext.
       Recovery is still possible by generating a checksum of the decrypted plaintext and returning
       to PPro for compare.
       
       It is significantly slower, so it helps to know the timestamp and use other module instead ;-)


   Speed of module:
   ++++++++++++++++
       At the moment, module is quite slow..something like 400,000 k/s on 2.66mhz E6750
       It will be optimized at some point..but don't expect major improvement on current speed.


   Notes:
   ++++++
       For example of decoding timestamp, look at kv5.cpp included with module.
       If you have questions, direct them to author email or post on forum.insidepro.com
   

   [+] 7th Jan 2009

       1st release

