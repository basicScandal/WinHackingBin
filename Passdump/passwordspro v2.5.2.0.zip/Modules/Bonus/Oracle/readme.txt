
        ORACLE PasswordsPro modules
        +++++++++++++++++++++++++++

Software required
    * PasswordsPro - http://www.insidepro.com/

Introduction
++++++++++++

These modules were created for ORACLE database DES and SHA-1 derived 
password hashes.

Note that usernames and passwords are limited to 32 bytes each when using 
both DES based modules.

ORACLE DES based hashes are originally limited to this length anyway.

IMPORTANT : when selecting brute force options,
for DES modules, do NOT select lowercase characters a-z, as these are
not converted to uppercase and are thus pointless to use.

If you want to check alphabetic A-Z, select A-Z in brute force options.

There is 127 byte limit for SHA-1 derived hashes.


DES-CBC <= 10g hashes
+++++++++++++++++++++

Both the username (e.g sys) and password (ex. password)
are converted to uppercase.
Then they are concatenated together, beginning with username.

    e.g SYSPASSWORD

This is then converted to UNICODE format for big-endian architecture.
Create a DES key schedule based on static value

    0x01,0x23,0x45,0x67,0x89,0xab,0xcd,0xef

Use DES CBC mode to encrypt the username/password using the DES key.
Then with the 8-byte result of this, create another DES key.

Once again using DES CBC mode, encrypt the username/password string.
The result is the ORACLE password hash.

Many thanks to Simon Marechal for source code example.


SHA-1 11g > hashes
++++++++++++++++++

The password is case-sensitive.
It is appended with an 80-bit random value.
Then hashed with SHA-1..very simple, pretty insecure too.

IMHO, more insecure than the older version based on DES.
I have good reason to say this..time will tell.

++++++++++++++++++++++++++++++++++++++

Feb 5th - version 1.1b
   * update to reflect API changes
   * 32-bit only version is removed temporarily.

Dec 30th - Version 1.0
   * fixed some silly bugs
   
Oct 24th - Version 1.0b
   * pre-release

send all bugs/comments to Kevin Devine <wyse101@gmail.com>
